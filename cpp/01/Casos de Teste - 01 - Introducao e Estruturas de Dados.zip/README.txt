Arquivo zip gerado em: 11/08/2023 15:32:03 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: 01 - Introdução e Estruturas de Dados